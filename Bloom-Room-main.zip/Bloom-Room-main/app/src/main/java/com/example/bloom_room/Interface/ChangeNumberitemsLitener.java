package com.example.bloom_room.Interface;

public interface ChangeNumberitemsLitener {
    void changed();
}
